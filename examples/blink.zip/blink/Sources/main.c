/*
 ============================================================================
 Description : Basic C Main
 ============================================================================
 */
#include "derivative.h"
#include "utilities.h"

#define COUNT ((1 << 16)-1)

/*
 * LED blink example
 * Working project
 * Use it as a model
 * Connect LED to PTED2
 */


int main(void) {

	unsigned short i = 0;

	// Set PTE2 as output and clear it
	PTEDD |= (1 << 2);
	PTECLR |= (1 << 2);

   // Real programs never die!
   for(;;) {

	   if (++i >= COUNT){
		   i = 0;
		   // Toggle LED
		   PTETOG |= (1 << 2);
	   }

   }
}
