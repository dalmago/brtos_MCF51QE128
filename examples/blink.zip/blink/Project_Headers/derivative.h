/*
 *  Include the derivative-specific header file
 */
#include "MCF51QE128.h"
